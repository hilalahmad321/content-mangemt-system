<?php
$conn=mysqli_connect("localhost","root","","cms-ajax");
?>