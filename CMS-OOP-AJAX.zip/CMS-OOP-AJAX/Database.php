<?php

class Database{
    private $db_localhost="localhost";
    private $db_username="root";
    private $db_password="";
    private $db_name="cms-ajax";
    private $mysqli="";


    public function __construct()
    {
        if(!$this->mysqli){
            $this->mysqli=new mysqli($this->db_localhost,$this->db_username,$this->db_password,$this->db_name);
            if(!$this->mysqli){
                echo "Connection is not good";
            }
            //else{
            //     echo "Connectioin is good";
            // }
        }
    }
    // Login
    public function login($table,$row="*",$where){
        $sql="SELECT $row FROM $table";
        if($where != null){
            $sql.=" WHERE $where";
        }
        $query=mysqli_query($this->mysqli,$sql);
        if(mysqli_num_rows($query)){
            while($row=mysqli_fetch_assoc($query)){
                session_start();
                $_SESSION["username"]=$row["username"];
            }
            return true;
        }
    }

    // Insert
    public function insertData($table,$value){
        $table_column=implode(",",array_keys($value));
        $table_value=implode("','",array_values($value));

        $sql="INSERT INTO $table ($table_column) VALUES('$table_value')";
        // var_dump($sql);
        $result=$this->mysqli->query($sql);
    }

    // Select
    public function selectData($table,$row="*",$join=null,$where=null,$order=null,$limit=null){
        $array=array();
       $sql="SELECT $row FROM $table";
        if($join != null){
            $sql.=" JOIN $join";
        }
        if($where != null){
            $sql.=" WHERE $where";
        }
        if($limit!=null){
            if(isset($_GET["page"])){
                $page=$_GET["page"];
            }else{
                $page=1;
            }
            $start=($page-1)*3;
            $sql.=" LIMIT $start,$limit";
        }
        $result=mysqli_query($this->mysqli,$sql);
        // if(mysqli_num_rows($result)>0){
            while($row=mysqli_fetch_assoc($result)){
                $array[]=$row;
                
            }
            return $array;
        // }
    }
    // Delete
    public function deleteData($table,$where){
        $sql="DELETE FROM $table";
        if($where != null){
            $sql.=" WHERE $where";
        }
        $result=$this->mysqli->query($sql);
    }
    // update
    public function updateData($table,$parm=array(),$where=null){
        $arg=array();
        foreach($parm as $key=>$value){
            $arg[]=" $key = '$value'";
        }
        $sql="UPDATE $table SET ".implode(",",$arg);
        if($where != null){
            $sql.=" WHERE $where";
        }
        $query=$this->mysqli->multi_query($sql);
    }
}
