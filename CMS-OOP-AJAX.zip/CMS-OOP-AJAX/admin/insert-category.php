<?php

include "../Database.php";

$obj=new Database();

$cname=$_POST["category_name"];

$obj->insertData("category",["category_name"=>$cname]);
if($obj){
    echo 1;
}else{
    echo 0;
}


?>