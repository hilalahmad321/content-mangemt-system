<?php
include "sidebar.php";
$obj = new Database();
?>
<div class="container">
    <div class="w3-right">
        <button class="btn w3-gray" onclick="document.getElementById('id01').style.display='block'">Add Category</button>
    </div>
</div>
<div class="container">
    <input type="text" name="search" placeholder="Search Here ......" id="search" class="w3-input mt-5 w3-border">
</div>
<div class="container">
    <div class="w3-modal" id="id01">
        <div class="w3-modal-content w3-animate-top" style="width: 50%;">
            <span onclick="document.getElementById('id01').style.display='none'" class="btn w3-red mb-5 mr-5 w3-display-bottomright">Close</span>
            <h1 class="w3-center pt-3">Category</h1>
            <form action="" method="POST" class="p-5">
                <label for="">Enter the Category</label>
                <input type="text" value="" class="w3-input w3-border" name="cname" id="cname">
                <button class="btn w3-green mt-2" type="submit" id="submit" name="submit">Category</button>
            </form>
        </div>
    </div>
</div>
<div class="container table-content">
</div>
<script src="js/jquery.js"></script>
<script>
    $(document).ready(function() {
        // Load data using ajax and oop
        function loaddata() {
            $.ajax({
                url: "select-category.php",
                type: "POST",
                success: function(data) {
                    $(".table-content").html(data);
                }
            });
        }
        loaddata();
        // insert data using ajax and oop
        $("#submit").on("click", function(e) {
            e.preventDefault();
            $(".w3-modal").hide();
            var category = $("#cname").val();
            $("form").trigger("reset");
            $.ajax({
                url: "insert-category.php",
                type: "POST",
                data: {
                    category_name: category
                },
                success: function(data) {
                    alert("Category Add Successfully");
                    loaddata();
                }
            });
        });
        $(document).on("click", "#deletebtn", function() {
            if (confirm("Are you sure you want to delete")) {
                var delete_id = $(this).data("id");
                var element = this;
                $.ajax({
                    url: "delete-category.php",
                    type: "POST",
                    data: {
                        del_id: delete_id
                    },
                    success: function(data) {
                        $(element).closest("tr").fadeOut();
                    }
                });
            }
        });
        // Search 
        $("#search").on("keyup", function() {
            var search = $(this).val();
            $.ajax({
                url: "live-search-category.php",
                type: "POST",
                data: {
                    search_term: search
                },
                success: function(data) {
                    $(".table-content").html(data);
                }
            });
        });
    });
</script>
<?php
include "footer.php";
?>