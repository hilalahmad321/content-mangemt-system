<?php
include "../config.php";
include "../Database.php";
$obj=new Database();
if(isset($_POST["submit"])){
         $title=$_POST["title"];
         $descr=$_POST["descr"];
         $date=$_POST["date"];
         $filename=$_FILES["img1"]["name"];		
        $tmp_name=$_FILES["img1"]["tmp_name"];
        $category=$_POST["category"];

        $name=time()."-".basename($filename);
        $target="post/".$name;
        $new_img=$name;
        move_uploaded_file($tmp_name,$target);
        $query="INSERT INTO post(title,descriptio,category,post_date,img)VALUES('{$title}','{$descr}','{$category}','{$date}','{$new_img}');";
        $query.="UPDATE category SET post=post+1 WHERE cat_id='{$category}'";

        $result=mysqli_multi_query($conn,$query);
        // $obj->insertData("post",$arg);
        // $obj->updateData("category",["post=>post+1"],"cat_id='{$category}'");
        if($result){
            echo "<script>alert('Post Add Successfully')</script>";
            echo "<script>window.open('post.php','_self')</script>";
        }
}
