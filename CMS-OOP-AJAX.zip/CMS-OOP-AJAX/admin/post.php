<?php
include "sidebar.php";
$obj = new Database();
?>
<div class="container">
    <div class="w3-right">
        <button class="btn w3-gray" onclick="document.getElementById('id01').style.display='block'">Add Post</button>
    </div>
</div>
<div class="container">
    <input type="text" name="search" placeholder="Search Here ......" id="search" class="w3-input mt-5 w3-border">
</div>
<div class="container">
    <div class="w3-modal" id="id01">
        <div class="w3-modal-content w3-animate-top" style="width:50%;">
        <span onclick="document.getElementById('id01').style.display='none'" class="btn w3-red mb-4 mr-4 w3-display-bottomright">Close</span>
            <h1 class="w3-center">Post</h1>
            <form action="insert-post.php" method="post" enctype="multipart/form-data" class="w3-content p-4" >
                <label for="">Enter title</label>
                <input type="text" name="title" class="w3-input w3-border" id="title">
                <label for="">Enter Description</label>
                <textarea name="descr" id="descr" cols="5" rows="10" class="w3-input w3-border"></textarea>
                <label for="">Enter category</label>
                <select name="category" id="select" class="w3-input w3-select w3-border">
                <option value="1" disabled selected>Select option</option>
                    <?php
                    $myrow=$obj->selectData("category","*",null,null,null,null);
                    foreach($myrow as $row){
                       echo "<option value='{$row["cat_id"]}'>{$row["category_name"]}</option>";
                    }
                    ?>
                </select>
                <label for="">Enter Date</label>
                <input type="date" name="date" class="w3-input w3-border" id="date">
                <label for="">Enter Image </label>
                <input type="file" name="img1" id="img1" class="w3-input w3-border">
                <!-- <label for="">Enter Image 1</label>
                <input type="file" name="img1" id="img1" class="w3-input w3-border">
                <label for="">Enter Image 3</label> -->
                <!-- <input type="file" name="img1" id="img1" class="w3-input w3-border"> -->
                <button type="submit" name="submit" class="btn w3-green mt-3" id="submit">Submit</button>
            </form>
        </div>
    </div>
</div>
<div class="container table-content">
</div>
<script src="js/jquery.js"></script>
<script>
    $(document).ready(function(){

        function loaddata(){
            $.ajax({
                url:"select-post.php",
                type:"POST",
                success:function(data){
                    $(".table-content").html(data);
                }
            });
        }
        loaddata();
        // search
        $("#search").on("keyup", function() {
            var search = $(this).val();
            $.ajax({
                url: "live-search-post.php",
                type: "POST",
                data: {
                    search_term: search
                },
                success: function(data) {
                    $(".table-content").html(data);
                }
            });
        });
    });
</script>
<?php
include "footer.php";
?>