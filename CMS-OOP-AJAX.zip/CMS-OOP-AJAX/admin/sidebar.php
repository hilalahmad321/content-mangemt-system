<?php
include "../Database.php";
include "header.php";
?>
<div class="w3-sidebar w3-bar-block w3-gray w3-text-white fixed-top w3-border-right w3-animate-left" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-large">Close &times;</button>
  <a href="dashboard.php" class="w3-bar-item w3-button p-3 mt-2">Dashboard</a>
  <a href="category.php" class="w3-bar-item w3-button p-3 mt-2">Category</a>
  <a href="post.php" class="w3-bar-item w3-button p-3 mt-2">Post</a>
</div>

<!-- Page Content -->
  <button class="w3-button w3-hover-gray w3-gray w3-xlarge" style="margin-top: -100px;" onclick="w3_open()">☰</button>
<script>
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>
<?php
include "footer.php";
?>