<?php
session_start();
include "../Database.php";
$obj=new Database();
if(isset($_SESSION["username"])){
    echo "<script>window.open('dashboard.php','_self')</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <title>Admin | pannel</title>
</head>
<style>
    body{
        background-color: crimson;
    }
</style>
<body>
    <?php
    if(isset($_POST["submit"])){
        $username=$_POST["username"];
        $pass=$_POST["pass"];
    
    if($obj->login("admins","username,passwrd","username='{$username}' AND passwrd='{$pass}'")){
        echo "<script>alert('Welcome Back')</script>";
        echo "<script>window.open('dashboard.php','_self')</script>";
    }
    else{
        echo "invalid usename and password";
    }
}
    ?>
<div class="container" style="margin-top: 10%;">
    <form action="" method="POST" class="w3-content mt-5 w3-white p-5 w3-round-xxlarge" style="width: 50%;">
        <h1 class="w3-center w3-jumbo">Admin Login</h1>
        <label for="">Enter Username</label>
        <input type="text" name="username" id="username" class="w3-input w3-border">
        <label for="">Enter Password</label>
        <input type="text" name="pass" id="pass" class="w3-input w3-border">
        <button class="w3-green btn mt-3" type="submit" name="submit">Login</button>
    </form>
</div>
</body>
</html>
<?php
include "footer.php";
?>