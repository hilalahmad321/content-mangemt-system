<?php
include "../config.php";
include "sidebar.php";
$obj=new Database();
if(isset($_GET["edit"])){
    $edit=$_GET["edit"];
  // $arg=array(
        //     "title"=>$_POST["title"],
        //     "description"=>$_POST["descr"],
        //     "category"=>$category,
        //     "post_date"=>$_POST["date"],
        //     "img"=>$rand.$filename
        // );
        $join="category ON post.category=category.cat_id";
        $myrow=$obj->selectData("post","*",$join,"post_id='{$edit}'",null,null,null);
        foreach($myrow as $row1){
            $title=$row1["title"];
            $descr=$row1["descriptio"];
            $cat_id=$row1["cat_id"];
            $category_id=$row1["category"];
            $category=$row1["category_name"];
            $date=$row1["post_date"];
            $img=$row1["img"];
?>
<div class="container">
    <div class="" id="id01">
        <div class="w3-content w3-animate-top" style="width:50%;">
            <h1 class="w3-center">Post</h1>
            <form action="<?php $_SERVER["PHP_SELF"]?>" method="post" enctype="multipart/form-data" class="w3-content p-4" >
                <label for="">Enter title</label>
                <input type="text" value="<?php echo $title;?>" name="title" class="w3-input w3-border" id="title">
                <label for="">Enter Description</label>
                <textarea name="descr" value="" id="descr" cols="5" rows="10" class="w3-input w3-border"><?php echo $descr;?></textarea>
                <label for="">Enter category</label>
                <select name="category" id="select"  class="w3-input w3-select w3-border">
                <!-- <option value="1" disabled selected>Select option</option> -->
                <!-- <option value='<?php// echo $cat_id?>'><?php// echo $category?></option> -->
                    <?php
                    $myrow=$obj->selectData("category","*",null,null,null,null);
                    foreach($myrow as $row){
                        if($row1["category"]==$row["cat_id"]){
                            $select="selected";
                        }else{
                            $select="";
                        }
                       echo " <option {$select} value='{$row["cat_id"]}'>{$row["category_name"]}</option> ";
                    }
                    ?>
                    
                </select>
                <input type="hidden" name="old_category" class="w-input w3-border" id="" value="<?php echo $row1["category"]?>">
                <label for="">Enter Date</label>
                <input type="date" name="date" value='<?php echo $date?>' class="w3-input w3-border" id="date">
                <label for="">Enter Image </label>
                <input type="file" name="img1" id="img1" class="w3-input w3-border" required/>
               <img src="post/<?php echo $img?>" style="width:150px;height:150px;" alt=""> <br>
               <input type="hidden" name="oldimg" id="" value="<?php echo $img?>" class="w3-input w3-border">
                <button type="submit" name="submit" class="btn w3-green mt-3" id="submit">Submit</button>
            </form>
        </div>
    </div>
</div>

<?php
        }
    }

if(isset($_GET["edit"])){
    $update=$_GET["edit"];
}
// if(empty($_FILES["img1"]["name"])){
//     $filename=$_POST["oldimg"];
// }
// else{
    if(isset($_POST["submit"])){
        $title=$_POST["title"];
        $descr=$_POST["descr"];
        $date=$_POST["date"];
        $filename=$_FILES["img1"]["name"];		
       $tmp_name=$_FILES["img1"]["tmp_name"];
       $category=$_POST["category"];
       $old=$_POST["old_category"];
       $name=time()."-".basename($filename);
       $target="post/".$name;
       move_uploaded_file($tmp_name, $target);
       $updateData="UPDATE post SET title='{$title}',descriptio='{$descr}',category='{$category}',post_date='{$date}',img='{$name}' WHERE post_id={$update};";
       if($old!=$category){
        $updateData .="UPDATE category SET post=post-1 WHERE cat_id={$old};";
        $updateData .="UPDATE category SET post=post+1 WHERE cat_id={$category};";
       }
       $result=mysqli_multi_query($conn,$updateData);
       if($result){
        echo "<script>alert('Post Update Successfully')</script>";
        echo "<script>window.open('post.php','_self')</script>";
       }else{
        echo "<script>alert('Post Update Cannot Successfully')</script>";
       }
}
// }
?>