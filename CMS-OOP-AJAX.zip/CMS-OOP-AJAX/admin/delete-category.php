<?php
include "../Database.php";
$obj=new Database();
$id=$_POST["del_id"];
$obj->deleteData("category","cat_id='$id'");
if($obj){
    echo 1;
}else{
    echo 0;
}
