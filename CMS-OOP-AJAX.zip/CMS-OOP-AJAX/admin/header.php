<?php
session_start();
if(!isset($_SESSION["username"])){
    echo "<script>window.open('index.php','_self')</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/w3.css">
    <title>Admin || Pannel</title>
</head>
<style>
a:hover{
    text-decoration: none;
}
</style>
<body>
    <div class="container-fluid w3-gray">
        <div class="container">
            <div class="w3-bar w3-xxlarge w3-text-white">

                <a href="Dashboard.php" class="w3-bar-item">Blog Website</a>
                <?php
                if(isset($_SESSION["username"])){
                    echo "<a href='logout.php' class='w3-bar-item w3-right w3-text-blue'>{$_SESSION["username"]}</a>";
                }
                ?>
                <a href='logout.php' class='w3-bar-item w3-right'>Logout</a>
            </div>
        </div>
    </div>
<?php
include "footer.php";
?>