<?php
include "sidebar.php";
include "../config.php";
$obj=new Database();
?>
<div class="container">
    <div class="row">
        <div class="col-md-4 ">
            <div class="w3-card-4 p-4 w3-blue">
            <?php
            $query="SELECT * FROM post";
            $result=mysqli_query($conn,$query);
            $total=mysqli_num_rows($result);
            ?>
                <span class="w3-xxlarge ">Post</span>
                <span class="w3-right w3-xxlarge"><?php echo $total;?></span>
            </div>
        </div>
        <div class="col-md-4 ">
        <?php
            $query="SELECT * FROM category";
            $result=mysqli_query($conn,$query);
            $total=mysqli_num_rows($result);
            ?>
            <div class="w3-card-4 p-4 w3-red">
                <span class="w3-xxlarge ">Category</span>
                <span class="w3-right w3-xxlarge"><?php echo $total;?></span>
            </div>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>