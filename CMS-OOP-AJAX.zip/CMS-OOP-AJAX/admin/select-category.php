<?php
include "../Database.php";
$obj=new Database();
$myrow=$obj->selectData("category","*",null,null,null,null);
$output="";
$output.="<table class='w3-table w3-table-all mt-5'>
                <tr class='w3-red'>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Post</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";
    foreach($myrow as $row){
    $output.="<tr>
    <td>{$row["cat_id"]}</td>
    <td>{$row["category_name"]}</td>
    <td>{$row["post"]}</td>
    <td><a href='update-category.php?edit={$row["cat_id"]}' class='btn w3-green'>Edit</a></td>
    <td><button class='btn w3-red'  id='deletebtn' data-id='{$row["cat_id"]}'>Delete</button></td>
</tr>";
}
$output.="</table>";
echo $output;
?>
