<?php

include "../Database.php";
$obj=new Database();
$search=$_POST["search_term"];
$join="category ON post.category=category.cat_id";
$myrow=$obj->selectData("post","post.post_id,post.title,post.category,post.post_date,post.img,category.category_name,category.cat_id",$join,"title LIKE '%{$search}%' OR category_name LIKE '%{$search}%'",null,null);
$output="";
$output.="<table class='w3-table w3-table-all mt-5'>
                <tr class='w3-red'>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th>Image</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";
    foreach($myrow as $row){
        $output.="<tr>
                    <td>{$row["post_id"]}</td>
                    <td>{$row["title"]}</td>
                    <td>{$row["category_name"]}</td>
                    <td>{$row["post_date"]}</td>
                    <td><img src='post/{$row["img"]}' alt='' style='width:40px;height:50px'></td>
                    <td><a href='update-post.php?edit={$row["post_id"]}' class='btn w3-green'>Edit</a></td>
                    <td><a href='delete-post.php?postid={$row["post_id"]}&catid={$row["cat_id"]}' class='btn w3-red'  id='deletebtn' data-id='{$row["post_id"]}'>Delete</a></td>
                </tr>";
    }
    echo $output;
?>
