<?php
include "../config.php";
include "../Database.php";
$obj=new Database();

// $dele=$_POST["del_id"];
$cateid=$_GET["catid"];
$post=$_GET["postid"];


// unlink("post/".$row["img"]);
$query="DELETE FROM post WHERE post_id='{$post}';";
$query .="UPDATE category SET post=post-1 WHERE cat_id='{$cateid}'";
$result=mysqli_multi_query($conn,$query);

if($result){
    echo "<script>alert('Post Delete Successfully')</script>";
    echo "<script>window.open('post.php','_self')</script>";
}else{
    echo 0;
}


?>