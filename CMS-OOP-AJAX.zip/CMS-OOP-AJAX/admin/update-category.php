<?php
include "sidebar.php";
// include "../Database.php";
$obj=new Database();
if(isset($_GET["edit"])){
    $eidt=$_GET["edit"];
}
$myrow=$obj->selectData("category","*",null,"cat_id='{$eidt}'",null,null);
foreach($myrow as $row){
    $catname=$row["category_name"];
    // echo $catname;
}
?>
           <div class="container w3-animate-top" style="width: 50%;">
            <!-- <span onclick="document.getElementById('id02').style.display='none'" class="btn w3-red mb-5 mr-5 w3-display-bottomright">Close</span> -->
            <h1 class="w3-center pt-3">Category</h1>
            <form action="" method="POST" class="p-5">
                <label for="">Enter the Category</label>
                <input type="text" value="<?php echo $catname;?>" class="w3-input w3-border" name="cname" id="cname">
                <button class="btn w3-green mt-2" type="submit" id="submit" name="update">Category</button>
            </form>
        </div>
<?php
if(isset($_GET["edit"])){
    $id=$_GET["edit"];
    if(isset($_POST["update"])){
$catename=$_POST["cname"];
$obj->updateData("category",["category_name"=>$catename],"cat_id='{$id}'");
if($obj){
    echo "<script>alert('Data update successfully')</script>";
    echo "<script>window.open('category.php','_self')</script>";
}
}
}

?>