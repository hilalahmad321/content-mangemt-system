<?php
include "Database.php";
$obj=new Database();

$page=basename($_SERVER["PHP_SELF"]);

switch($page){
    case "category.php":
        if(isset($_GET["cat_id"])){
            $myrow=$obj->selectData("category","*",null,"cat_id='{$_GET["cat_id"]}'",null,null);
            foreach($myrow as $row){
                $page_title=$row["category_name"];
            }
        }else{
            $page_title="No recoud found";
        }
        break;
    case "single.php":
        if(isset($_GET["postid"])){
            $myrow=$obj->selectData("post","*",null,"post_id='{$_GET["postid"]}'",null,null);
            foreach($myrow as $row){
                $page_title=$row["title"];
            }
        }else{
            $page_title="No recoud found";
        }
        break;
    case "search.php":
        if(isset($_GET["search"])){
                $page_title=$_GET["search"];
        }else{
            $page_title="No recoud found";
        }
        break;
    default:
        $page_title="Webdevelopment and design tutorial";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>JavaPoint -- <?php echo $page_title?></title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="admin/css/w3.css">
    <!-- Custom stlylesheet -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<!-- HEADER -->
<div id="header">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- LOGO -->
            <div class="w3-bar w3-xxlarge">
                <a href="index.php" class="w3-bar-item" >JavaPoint</a>
                <a href="index.php" class="w3-bar-item w3-right" >JavaPoint</a>
            </div>
            <!-- /LOGO -->
        </div>
    </div>
</div>
<!-- /HEADER -->
<!-- Menu Bar -->
<div id="menu-bar">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ul class='menu' style="text-align:left;">
                    <li><a href='index.php' class="<">Home</a></li>
                    <?php
                    
                    if(isset($_GET["cat_id"])){
                        $cat_id=$_GET["cat_id"];
                    }
                    $active="";
                        $myrow=$obj->selectData("category","*",null,"post>0",null,null);
                        foreach($myrow as $row){
                            if(isset($_GET["cat_id"])){
                            if($row["cat_id"]==$cat_id){
                                $active="w3-blue";
                            }else{
                                $active="";
                            }
                        }
                            echo "<li><a href='category.php?cat_id={$row["cat_id"]}' class='{$active}'>{$row["category_name"]}</a></li>";
                        }
                    ?>
                    
                    <!-- <li><a href='category.php'>CSS</a></li>
                    <li><a href='category.php'>Javascruot</a></li> -->
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- /Menu Bar -->
