hello


this is cms website using little jquery,ajax,oops,and php

adminlogin
username=admin
password=admin

Thank for downloading