<?php include 'header.php';
$obj = new Database();
$active="home";
?>
<div id="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <!-- post-container -->
                <div class="post-container">
                    <?php
                    $join="category ON post.category=category.cat_id";
                    $myrow = $obj->selectData("post", "*", $join, null, "ORDER BY post_id DESC", null);
                    foreach ($myrow as $row) {
                    ?>
                        <div class="post-content">
                            <div class="row">
                                <div class="col-md-4">
                                    <a class="post-img" href="single.php?postid=<?php echo $row["post_id"]?>"><img src="admin/post/<?php echo $row["img"]?>" alt="" /></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="inner-content clearfix">
                                        <h3><a href='single.php?postid=<?php echo $row["post_id"]?>'><?php echo $row["title"]?></a></h3>
                                        <div class="post-information">
                                            <span>
                                                <i class="fa fa-tags" aria-hidden="true"></i>
                                                <a href='category.php?cat_id=<?php echo $row["cat_id"]?>'><?php echo $row["category_name"]?></a>
                                            </span>
                                            <span>
                                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                                <?php echo $row["post_date"]?>
                                            </span>
                                        </div>
                                        <p class="description">
                                        <?php echo substr($row["descriptio"],0,300)."..."?>
                                        </p>
                                        <a class='read-more pull-right' href='single.php?postid=<?php echo $row["post_id"]?>'>read more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                    
                </div><!-- /post-container -->
            </div>
            
            <?php include 'sidebar.php'; ?>
           
        </div>
    </div>

</div>
<?php include 'footer.php'; ?>