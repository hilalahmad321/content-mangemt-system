<div id="sidebar" class="col-md-4">
    <!-- search box -->
    <div class="search-box-container">
        <h4>Search</h4>
        <form class="search-post" action="search.php" method ="GET">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search ....." required/>
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-danger">Search</button>
                </span>
            </div>
        </form>
    </div>
    <!-- /search box -->
    <!-- recent posts box -->
    <div class="recent-post-container">
        <h4>Recent Posts</h4>
        <?php
        include "config.php";
        // $obj=new Database();
        // $limit=4;
        $query="SELECT * FROM post JOIN category ON post.category=category.cat_id  ORDER BY post_id DESC LIMIT 4";
        $result=mysqli_query($conn,$query);
        //  $join="category ON post.category=category.cat_id";
        //  $myrow = $obj->selectData("post", "*", $join, null, " ORDER BY post DESC ", $limit);
        while($row=mysqli_fetch_assoc($result)){
        ?>
        <div class="recent-post">
            <a class="post-img" href="postid=<?php echo $row["post_id"]?>"><img src="admin/post/<?php echo $row["img"]?>"/>
            </a>
            <div class="post-content">
                <h5><a href='single.php?postid=<?php echo $row["post_id"]?>'><?php echo $row["title"]?></a></h5>
                <span>
                    <i class="fa fa-tags" aria-hidden="true"></i>
                    <a href='category.php?cat_id=<?php echo $row["cat_id"]?>'><?php echo $row["category_name"]?></a>
                </span>
                <span>
                    <i class="fa fa-calendar" aria-hidden="true"></i>
                    <?php echo $row["post_date"]?>
                </span>
                <a class='read-more pull-right' href='single.php?postid=<?php echo $row["post_id"]?>'>read more</a>
            </div>
        </div>
        <?php
         }
        ?>
    </div>
    <!-- /recent posts box -->
    <div class="recent-post-container" style="margin-top: 20px;">
        <h4>Total post</h4>
        <?php
        include "config.php";
        // $obj=new Database();
        // $limit=4;
        $query="SELECT * FROM category";
        $result=mysqli_query($conn,$query);
        //  $join="category ON post.category=category.cat_id";
        //  $myrow = $obj->selectData("post", "*", $join, null, " ORDER BY post DESC ", $limit);
        while($row=mysqli_fetch_assoc($result)){
        ?>
        <div class="recent-post">
            <div class="post-content">
                    <i class="fa fa-tags" aria-hidden="true"></i>
                    <a href='category.php?cat_id=<?php echo $row["cat_id"]?>'><?php echo $row["category_name"]?></a>
                    <span style="background-color:lightblue; font-size:1.5rem;padding:10px;border-radius:50%;"><?php echo $row["post"]?></span>
            </div>
        </div>
        <?php
         }
        ?>
    </div>
</div>
