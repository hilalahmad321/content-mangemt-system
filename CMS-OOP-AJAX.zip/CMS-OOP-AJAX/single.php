<?php include 'header.php';

$obj = new Database();
?>
<div id="main-content">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <!-- post-container -->
                <?php
                if (isset($_GET["postid"])) {
                    $post = $_GET["postid"];
                    $join = "category ON post.category=category.cat_id";
                    $myrow = $obj->selectData("post", "*", $join, "post_id='{$post}'", null, null);
                    foreach ($myrow as $row) {
                        $title = $row["title"];
                        $desc = $row["descriptio"];
                        $date = $row["post_date"];
                        $img = $row["img"];
                        $category = $row["category_name"];
                    }
                }
                ?>
                <div class="post-container">
                    <div class="post-content single-post">
                        <h3><?php echo $title ?></h3>
                        <div class="post-information">
                            <span>
                               <a href="category.php?cat_id=<?php echo $row["cat_id"]?>"> <i class="fa fa-tags" aria-hidden="true"></i>
                                <?php echo $category ?></a>
                            </span>
                            <span>
                                <i class="fa fa-calendar" aria-hidden="true"></i>
                                <?php echo $date?>
                            </span>
                        </div>
                        <img class="single-feature-image" src="admin/post/<?php echo $img?>" alt="" />
                        <p class="description">
                        <?php echo $desc?>
                        </p>
                    </div>
                </div>
                <!-- /post-container -->
            </div>
            <?php include 'sidebar.php'; ?>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>